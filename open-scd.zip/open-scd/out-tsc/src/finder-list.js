import { __decorate } from "../../_snowpack/pkg/tslib.js";
import { css, customElement, html, LitElement, property, query, } from '../../_snowpack/pkg/lit-element.js';
import { until } from '../../_snowpack/pkg/lit-html/directives/until.js';
import { translate } from '../../_snowpack/pkg/lit-translate.js';
function depth(t, mem = new WeakSet()) {
    if (mem.has(t))
        return Infinity;
    else
        switch ((mem.add(t), t?.constructor)) {
            case Object:
            case Array:
                return (1 +
                    Math.max(-1, ...Object.values(t).map(_ => depth(_, mem))));
            default:
                return 0;
        }
}
const waitingList = html `<div class="column">
  <mwc-list
    ><mwc-list-item noninteractive hasMeta
      >${translate('loading')}<mwc-icon slot="meta"
        >pending</mwc-icon
      ></mwc-list-item
    ></mwc-list
  >
</div>`;
let FinderList = class FinderList extends LitElement {
    constructor() {
        super(...arguments);
        this.selected = {};
        this.read = async (path) => {
            return {
                path,
                header: html `<h2>${'/' + path.join('/')}</h2>`,
                entries: [],
            };
        };
        this.loaded = Promise.resolve();
    }
    get depth() {
        return depth(this.selected);
    }
    paths(depth = this.depth) {
        let ps = Object.keys(this.selected).map(key => [key]);
        while (depth-- > 0) {
            ps = ps.flatMap(path => {
                let dir = this.selected;
                for (const entry of path)
                    dir = dir[entry]; // recursive descent
                return Object.keys(dir).map(entry => path.concat(entry));
            });
        }
        return ps;
    }
    async select(event, path) {
        const clicked = event.target.selected.text;
        let dir = this.selected;
        for (const entry of path)
            dir = dir[entry]; // recursive descent
        if (dir && dir[clicked])
            delete dir[clicked];
        else
            dir[clicked] = {};
        this.requestUpdate();
        await this.updateComplete;
        await new Promise(resolve => setTimeout(resolve, 250));
        this.container.scrollLeft = 1000 * this.depth;
    }
    renderDirectory(path, entries) {
        return html `<filtered-list
      @selected=${(e) => this.select(e, path)}
      .searchFieldLabel="${path.join('/')}"
    >
      ${entries.map(entry => html `<mwc-list-item
            ?activated=${this.paths(path.length)
            .map(p => JSON.stringify(p))
            .includes(JSON.stringify(path.concat(entry)))}
            >${entry}</mwc-list-item
          >`)}
    </filtered-list>`;
    }
    async renderColumn(column = 0) {
        const paths = this.paths(column);
        const lists = paths
            .map(path => this.read(path))
            .map(dir => html `${until(dir.then(({ path, entries, header }) => html `<h2>${path.join(' ')}</h2>
                  ${header} ${this.renderDirectory(path, entries)}
                  <pre>${entries.join('\n')}</pre>`), html `<h2>${translate('loading')}</h2>`)}`);
        return html `<div class="column">${lists}</div>`;
    }
    render() {
        const columns = new Array(this.depth)
            .fill(0)
            .map((_, index) => this.renderColumn(index));
        this.loaded = Promise.allSettled(columns).then();
        return html `<div class="pane">
      ${columns.map(column => until(column, waitingList))}
    </div>`;
    }
};
FinderList.styles = css `
    div.pane {
      display: flex;
      flex-direction: row;
      overflow: auto;
    }

    h2 {
      color: var(--mdc-theme-primary);
    }

    section {
      display: flex;
      flex-direction: column;
      width: max-content;
    }

    section > mwc-list {
      margin-top: 76px;
    }

    a {
      font-weight: 600;
      font-variant: small-caps;
      text-transform: lowercase;
      text-decoration: none;
      color: var(--mdc-theme-primary);
    }

    a:link {
      color: var(--mdc-theme-error);
    }

    a:visited {
      color: var(--mdc-theme-secondary);
    }
  `;
__decorate([
    property({ type: Object })
], FinderList.prototype, "selected", void 0);
__decorate([
    property({ type: Number })
], FinderList.prototype, "depth", null);
__decorate([
    property({ attribute: false })
], FinderList.prototype, "read", void 0);
__decorate([
    property({ attribute: false })
], FinderList.prototype, "loaded", void 0);
__decorate([
    query('div')
], FinderList.prototype, "container", void 0);
FinderList = __decorate([
    customElement('finder-list')
], FinderList);
export { FinderList };
//# sourceMappingURL=finder-list.js.map