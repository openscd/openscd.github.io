import { __decorate } from "../../../_snowpack/pkg/tslib.js";
import { LitElement, property } from '../../../_snowpack/pkg/lit-element.js';
function formatXml(xml, tab) {
    let formatted = '', indent = '';
    if (!tab)
        tab = '\t';
    xml.split(/>\s*</).forEach(function (node) {
        if (node.match(/^\/\w/))
            indent = indent.substring(tab.length);
        formatted += indent + '<' + node + '>\r\n';
        if (node.match(/^<?\w[^>]*[^/]$/))
            indent += tab;
    });
    return formatted.substring(1, formatted.length - 3);
}
export default class SaveProjectPlugin extends LitElement {
    async run() {
        if (this.doc) {
            const blob = new Blob([formatXml(new XMLSerializer().serializeToString(this.doc))], {
                type: 'application/xml',
            });
            const a = document.createElement('a');
            a.download = this.docName;
            a.href = URL.createObjectURL(blob);
            a.dataset.downloadurl = ['application/xml', a.download, a.href].join(':');
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () {
                URL.revokeObjectURL(a.href);
            }, 5000);
        }
    }
}
__decorate([
    property()
], SaveProjectPlugin.prototype, "doc", void 0);
__decorate([
    property()
], SaveProjectPlugin.prototype, "docName", void 0);
//# sourceMappingURL=SaveProject.js.map