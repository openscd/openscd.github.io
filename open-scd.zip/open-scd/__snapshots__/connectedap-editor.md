# `connectedap-editor`

#### `looks like the latest snapshot`

```html
<div
  id="container"
  tabindex="0"
>
  <mwc-icon class="fancy">
    settings_input_hdmi
  </mwc-icon>
  <mwc-fab
    class="left menu-item"
    icon="edit"
    mini=""
  >
  </mwc-fab>
  <mwc-fab
    class="menu-item right"
    icon="delete"
    mini=""
  >
  </mwc-fab>
</div>
<h4>
  P1
</h4>

```

