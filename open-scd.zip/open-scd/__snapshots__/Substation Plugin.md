# `Substation Plugin`

## `without a doc loaded`

####   `looks like the latest snapshot`

```html
<zeroline-pane>
</zeroline-pane>
<h1>
  <mwc-fab
    extended=""
    icon="add"
    label="[substation.wizard.title.add]"
  >
  </mwc-fab>
</h1>
<wizard-dialog>
</wizard-dialog>

```

