# `wizard-dialog`

## `with a nonempty wizard property`

##   `in pro mode`

####     `looks like its snapshot`

```html
<wizard-dialog>
</wizard-dialog>

```

####     `switches to code editor view on code toggle button click`

```html
<wizard-dialog>
</wizard-dialog>

```

