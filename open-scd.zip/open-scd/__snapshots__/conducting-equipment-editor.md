# `conducting-equipment-editor`

#### `looks like the latest snapshot`

```html
<div
  id="container"
  tabindex="0"
>
  <mwc-fab
    class="left menu-item"
    icon="account_tree"
    mini=""
  >
  </mwc-fab>
  <mwc-fab
    class="menu-item up"
    icon="edit"
    mini=""
  >
  </mwc-fab>
  <mwc-fab
    class="menu-item right"
    icon="forward"
    mini=""
  >
  </mwc-fab>
  <mwc-fab
    class="down menu-item"
    icon="delete"
    mini=""
  >
  </mwc-fab>
</div>
<h4>
  QA1
</h4>

```

## `with readonly property`

####   `looks like the latest snapshot`

```html
<div
  id="container"
  tabindex="0"
>
</div>
<h4>
  QA1
</h4>

```

