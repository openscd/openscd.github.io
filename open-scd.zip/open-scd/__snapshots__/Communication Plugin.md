# `Communication Plugin`

## `without a doc loaded`

####   `looks like the latest snapshot`

```html
<h1>
  <span style="color: var(--base1)">
    [communication.missing]
  </span>
  <mwc-fab
    extended=""
    icon="add"
    label="[subnetwork.wizard.title.add]"
  >
  </mwc-fab>
</h1>
<wizard-dialog>
</wizard-dialog>

```

