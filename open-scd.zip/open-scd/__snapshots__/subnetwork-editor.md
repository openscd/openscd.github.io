# `subnetwork-editor`

#### `looks like the latest snapshot`

```html
<section tabindex="0">
  <h1>
    StationBus — desc
      (8-MMS—100.0b/s)
    <abbr title="[add]">
      <mwc-icon-button icon="playlist_add">
      </mwc-icon-button>
    </abbr>
    <nav>
      <abbr title="[edit]">
        <mwc-icon-button icon="edit">
        </mwc-icon-button>
      </abbr>
      <abbr title="[remove]">
        <mwc-icon-button icon="delete">
        </mwc-icon-button>
      </abbr>
    </nav>
  </h1>
  <div id="connAPContainer">
    <section
      id="iedSection"
      tabindex="0"
    >
      <h3>
        IED1
      </h3>
      <div id="connApContainer">
        <connectedap-editor>
        </connectedap-editor>
      </div>
    </section>
  </div>
</section>

```

