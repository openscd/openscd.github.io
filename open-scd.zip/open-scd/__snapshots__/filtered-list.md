# `filtered-list`

#### `looks like its latest snapshot`

```html
<div id="tfcontainer">
  <mwc-textfield
    icontrailing="search"
    label=""
    outlined=""
  >
  </mwc-textfield>
  <mwc-formfield class="checkall">
    <mwc-checkbox>
    </mwc-checkbox>
  </mwc-formfield>
</div>
<ul
  class="mdc-deprecated-list"
  tabindex="-1"
>
  <slot>
  </slot>
</ul>

```

