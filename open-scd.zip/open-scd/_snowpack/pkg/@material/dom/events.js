export { a as applyPassive } from '../../common/events-a64aa528.js';
