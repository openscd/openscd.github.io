export { c as closest, m as matches } from '../../common/ponyfill-4ccc5f83.js';
