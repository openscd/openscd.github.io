import { M as MDCSnackbarFoundation } from '../../common/foundation-67f0a2d5.js';
export { M as default } from '../../common/foundation-67f0a2d5.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
