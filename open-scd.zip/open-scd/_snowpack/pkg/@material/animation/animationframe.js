export { A as AnimationFrame } from '../../common/animationframe-3e5ba054.js';
