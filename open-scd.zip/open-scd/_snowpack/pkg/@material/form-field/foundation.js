import { M as MDCFormFieldFoundation } from '../../common/foundation-86d59bba.js';
export { M as default } from '../../common/foundation-86d59bba.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
