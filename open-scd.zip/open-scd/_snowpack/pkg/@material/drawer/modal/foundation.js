import { M as MDCModalDrawerFoundation } from '../../../common/foundation-6524728a.js';
export { M as default } from '../../../common/foundation-6524728a.js';
import '../../../common/index-9a80a8ad.js';
import '../../../common/foundation-573f37fb.js';
import '../../base/foundation.js';
import '../../../common/constants-d201262d.js';
