import { M as MDCDismissibleDrawerFoundation } from '../../../common/foundation-573f37fb.js';
export { M as default } from '../../../common/foundation-573f37fb.js';
import '../../../common/index-9a80a8ad.js';
import '../../base/foundation.js';
import '../../../common/constants-d201262d.js';
