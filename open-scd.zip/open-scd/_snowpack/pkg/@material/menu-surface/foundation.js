import { M as MDCMenuSurfaceFoundation } from '../../common/foundation-41bfb95f.js';
export { M as MDCMenuSurfaceFoundation, M as default } from '../../common/foundation-41bfb95f.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
import '../../common/constants-41ace9c4.js';
