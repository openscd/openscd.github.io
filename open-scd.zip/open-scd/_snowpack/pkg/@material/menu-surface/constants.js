export { C as Corner, a as CornerBit } from '../../common/constants-41ace9c4.js';
