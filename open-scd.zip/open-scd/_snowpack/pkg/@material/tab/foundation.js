import { M as MDCTabFoundation } from '../../common/foundation-d55ac8fc.js';
export { M as default } from '../../common/foundation-d55ac8fc.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
