export { M as MDCNotchedOutlineFoundation } from '../../common/foundation-fc5720d8.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
