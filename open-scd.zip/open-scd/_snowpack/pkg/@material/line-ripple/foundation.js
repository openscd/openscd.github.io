export { M as MDCLineRippleFoundation } from '../../common/foundation-065bca84.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
