export { M as MDCFloatingLabelFoundation } from '../../common/foundation-cf92dde8.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
