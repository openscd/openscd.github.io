import { M as MDCTextFieldFoundation } from '../../common/foundation-9d78fb6d.js';
export { M as default } from '../../common/foundation-9d78fb6d.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
