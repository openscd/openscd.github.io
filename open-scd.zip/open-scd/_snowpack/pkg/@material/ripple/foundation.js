import { M as MDCRippleFoundation } from '../../common/foundation-2d231415.js';
export { M as default } from '../../common/foundation-2d231415.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
