import { M as MDCTabBarFoundation } from '../../common/foundation-c0cf93bd.js';
export { M as default } from '../../common/foundation-c0cf93bd.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
