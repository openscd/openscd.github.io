import { M as MDCSwitchFoundation } from '../../../common/foundation-9f53279d.js';
export { M as default } from '../../../common/foundation-9f53279d.js';
import '../../../common/index-9a80a8ad.js';
import '../../base/foundation.js';
