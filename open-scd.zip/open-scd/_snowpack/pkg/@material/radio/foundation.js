import { M as MDCRadioFoundation } from '../../common/foundation-2109f4f9.js';
export { M as default } from '../../common/foundation-2109f4f9.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
