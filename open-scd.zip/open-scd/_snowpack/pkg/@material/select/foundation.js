import { M as MDCSelectFoundation } from '../../common/foundation-b9b48b41.js';
export { M as default } from '../../common/foundation-b9b48b41.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
import '../dom/keyboard.js';
import '../../common/constants-41ace9c4.js';
