import { M as MDCTopAppBarFoundation } from '../../../common/foundation-546d3def.js';
export { M as default } from '../../../common/foundation-546d3def.js';
import '../../../common/index-9a80a8ad.js';
import '../constants.js';
import '../foundation.js';
import '../../base/foundation.js';
