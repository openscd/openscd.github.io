import { M as MDCFixedTopAppBarFoundation } from '../../../common/foundation-b23bc632.js';
export { M as default } from '../../../common/foundation-b23bc632.js';
import '../../../common/index-9a80a8ad.js';
import '../constants.js';
import '../../../common/foundation-546d3def.js';
import '../foundation.js';
import '../../base/foundation.js';
