import { M as MDCDialogFoundation } from '../../common/foundation-d3ae99f3.js';
export { M as default } from '../../common/foundation-d3ae99f3.js';
import '../../common/index-9a80a8ad.js';
import '../../common/animationframe-3e5ba054.js';
import '../base/foundation.js';
import '../../common/constants-3a91ca71.js';
