export { f as floatingLabel } from '../common/mwc-floating-label-directive-16ee1a9b.js';
import '../common/foundation-cf92dde8.js';
import '../common/index-9a80a8ad.js';
import './base/foundation.js';
import '../common/directive-afe88016.js';
import '../common/lit-html-1055e278.js';
