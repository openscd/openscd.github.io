import { M as MDCMenuFoundation } from '../../common/foundation-52de454d.js';
export { M as default } from '../../common/foundation-52de454d.js';
import '../../common/index-9a80a8ad.js';
import '../base/foundation.js';
import '../list/constants.js';
import '../../common/foundation-41bfb95f.js';
import '../../common/constants-41ace9c4.js';
import '../../common/constants-aa3b5704.js';
