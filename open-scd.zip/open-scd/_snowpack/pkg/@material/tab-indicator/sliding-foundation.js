import { M as MDCSlidingTabIndicatorFoundation } from '../../common/sliding-foundation-68560901.js';
export { M as default } from '../../common/sliding-foundation-68560901.js';
import '../../common/index-9a80a8ad.js';
import '../../common/foundation-a27ed62c.js';
import '../base/foundation.js';
