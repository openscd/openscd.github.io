import { M as MDCFadingTabIndicatorFoundation } from '../../common/fading-foundation-09af8fc8.js';
export { M as default } from '../../common/fading-foundation-09af8fc8.js';
import '../../common/index-9a80a8ad.js';
import '../../common/foundation-a27ed62c.js';
import '../base/foundation.js';
