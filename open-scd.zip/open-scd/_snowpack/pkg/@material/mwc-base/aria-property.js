export { a as ariaProperty } from '../../common/aria-property-c2d6d3d3.js';
