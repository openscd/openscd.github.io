import { p as prand } from './common/pure-rand-default-fe519b2e.js';
export { p as default, s as skipN, b as unsafeUniformArrayIntDistribution, a as unsafeUniformBigIntDistribution, u as unsafeUniformIntDistribution } from './common/pure-rand-default-fe519b2e.js';
