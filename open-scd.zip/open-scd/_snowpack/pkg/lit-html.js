export { S as SVGTemplateResult, T as TemplateResult, h as html, s as svg } from './common/lit-html-1055e278.js';
