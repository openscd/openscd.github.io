# conducting-equipment-editor

[[`SubstationEditor`]] subeditor for a `ConductingEquipment` element.

## Properties

| Property   | Attribute  | Modifiers | Type      | Default |
|------------|------------|-----------|-----------|---------|
| `addMenu`  |            |           | `Menu`    |         |
| `element`  | `element`  |           | `Element` |         |
| `name`     | `name`     | readonly  | `string`  |         |
| `readonly` | `readonly` |           | `boolean` | false   |

## Methods

| Method                     | Type                                             | Description                                      |
|----------------------------|--------------------------------------------------|--------------------------------------------------|
| `openCreateWizard`         | `(tagName: "SCL" \| "SubNetwork" \| "GOOSESecurity" \| "SMVSecurity" \| "ConnectivityNode" \| "SubFunction" \| "Function" \| "TapChanger" \| "SubEquipment" \| "GeneralEquipment" \| "PowerTransformer" \| ... 112 more ... \| "SecPerSamples"): void` |                                                  |
| `openEditWizard`           | `(): void`                                       |                                                  |
| `openLNodeWizard`          | `(): void`                                       | Opens a [[`WizardDialog`]] for editing `LNode` connections. |
| `openSelectFunctionWizard` | `(): void`                                       |                                                  |
| `remove`                   | `(): void`                                       |                                                  |
