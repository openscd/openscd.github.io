# lnode-editor

## Properties

| Property  | Attribute | Modifiers | Type                | Default |
|-----------|-----------|-----------|---------------------|---------|
| `color`   | `color`   |           | `"light" \| "dark"` | "dark"  |
| `element` |           |           | `Element`           |         |
| `lnClass` | `lnClass` | readonly  | `string`            |         |
| `lnInst`  | `lnInst`  | readonly  | `string \| null`    |         |

## Methods

| Method           | Type                 |
|------------------|----------------------|
| `openEditWizard` | `(): void`           |
| `remove`         | `(): void`           |
| `renderHeader`   | `(): TemplateResult` |
