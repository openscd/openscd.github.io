# equipment-editor

[[`SubstationEditor`]] subeditor for a `ConductingEquipment` element.

## Properties

| Property        | Attribute       | Modifiers | Type                | Default |
|-----------------|-----------------|-----------|---------------------|---------|
| `addMenu`       |                 |           | `Menu`              |         |
| `color`         | `color`         |           | `"light" \| "dark"` | "dark"  |
| `element`       | `element`       |           | `Element`           |         |
| `name`          | `name`          | readonly  | `string`            |         |
| `readonly`      | `readonly`      |           | `boolean`           | false   |
| `showfunc`      |                 |           | `boolean`           | false   |
| `showfunctions` | `showfunctions` |           | `boolean`           | true    |

## Methods

| Method                     | Type                                             | Description                                      |
|----------------------------|--------------------------------------------------|--------------------------------------------------|
| `existFunction`            | `(): boolean`                                    |                                                  |
| `openCreateWizard`         | `(tagName: "SCL" \| "SubNetwork" \| "GOOSESecurity" \| "SMVSecurity" \| "ConnectivityNode" \| "SubFunction" \| "Function" \| "TapChanger" \| "SubEquipment" \| "GeneralEquipment" \| "PowerTransformer" \| ... 112 more ... \| "SecPerSamples"): void` |                                                  |
| `openEditWizard`           | `(): void`                                       |                                                  |
| `openLNodeWizard`          | `(): void`                                       | Opens a [[`WizardDialog`]] for editing `LNode` connections. |
| `openSelectFunctionWizard` | `(): void`                                       |                                                  |
| `remove`                   | `(): void`                                       |                                                  |
