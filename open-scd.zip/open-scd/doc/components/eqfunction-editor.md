# eqfunction-editor

## Properties

| Property   | Attribute  | Modifiers | Type                | Default |
|------------|------------|-----------|---------------------|---------|
| `color`    | `color`    |           | `"light" \| "dark"` | "dark"  |
| `desc`     | `desc`     | readonly  | `string \| null`    |         |
| `element`  |            |           | `Element`           |         |
| `moreMenu` |            |           | `Menu`              |         |
| `name`     | `name`     | readonly  | `string`            |         |
| `readonly` | `readonly` |           | `boolean`           | false   |

## Methods

| Method             | Type                                             |
|--------------------|--------------------------------------------------|
| `openCreateWizard` | `(tagName: "SCL" \| "SubNetwork" \| "GOOSESecurity" \| "SMVSecurity" \| "ConnectivityNode" \| "SubFunction" \| "Function" \| "TapChanger" \| "SubEquipment" \| "GeneralEquipment" \| "PowerTransformer" \| ... 112 more ... \| "SecPerSamples"): void` |
| `openEditWizard`   | `(): void`                                       |
| `remove`           | `(): void`                                       |
| `renderHeader`     | `(): TemplateResult`                             |
