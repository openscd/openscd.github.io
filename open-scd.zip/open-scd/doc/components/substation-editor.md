# substation-editor

[[`Substation`]] plugin subeditor for editing `Substation` sections.

## Properties

| Property          | Attribute       | Modifiers | Type                                             | Default                            | Description                                      |
|-------------------|-----------------|-----------|--------------------------------------------------|------------------------------------|--------------------------------------------------|
| `addMenu`         |                 |           | `Menu`                                           |                                    |                                                  |
| `desc`            | `desc`          | readonly  | `string \| null`                                 |                                    | [[element \| `element.desc`]]                    |
| `element`         |                 |           | `Element`                                        |                                    | The edited `Element`, a common property of all Substation subeditors. |
| `getAttachedIeds` |                 |           | `((element: Element) => Element[]) \| undefined` | "() => {\r\n    return [];\r\n  }" |                                                  |
| `name`            | `name`          | readonly  | `string`                                         |                                    | [[element \| `element.name`]]                    |
| `readonly`        | `readonly`      |           | `boolean`                                        | false                              |                                                  |
| `showfunctions`   | `showfunctions` |           | `boolean`                                        | false                              |                                                  |

## Methods

| Method                   | Type                                             | Description                                      |
|--------------------------|--------------------------------------------------|--------------------------------------------------|
| `openCreateWizard`       | `(tagName: "SCL" \| "SubNetwork" \| "GOOSESecurity" \| "SMVSecurity" \| "ConnectivityNode" \| "SubFunction" \| "Function" \| "TapChanger" \| "SubEquipment" \| "GeneralEquipment" \| "PowerTransformer" \| ... 112 more ... \| "SecPerSamples"): void` |                                                  |
| `openEditWizard`         | `(): void`                                       | Opens a [[`WizardDialog`]] for editing [[`element`]]. |
| `openLNodeWizard`        | `(): void`                                       | Opens a [[`WizardDialog`]] for editing `LNode` connections. |
| `openVoltageLevelWizard` | `(): void`                                       | Opens a [[`WizardDialog`]] for adding a new `VoltageLevel`. |
| `remove`                 | `(): void`                                       | Deletes [[`element`]].                           |
| `renderHeader`           | `(): TemplateResult`                             |                                                  |
| `renderIedContainer`     | `(): TemplateResult`                             |                                                  |
